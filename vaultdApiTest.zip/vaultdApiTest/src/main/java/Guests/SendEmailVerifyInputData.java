package Guests;

public class SendEmailVerifyInputData {
	private String email;

	public SendEmailVerifyInputData(String email) {
		this.email = email;
		
	}

	public void setEmail(String email) {
		this.email = email;
	}


	
	public String getEmail() {
		return email;
	}

	


}
